import org.apache.poi.hssf.record.formula.functions.Rows;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        ReaderExcel reader = new ReaderExcel("C:/temp/model.xls");
        try {
            Workbook workbook = reader.readExcel();
            Sheet sheet = workbook.getSheetAt(0);
            Cell cellDate = sheet.getRow(2).getCell(1);
            cellDate.setCellValue(new Date());
            Cell cellBusinessUnit = sheet.getRow(3).getCell(1);
            cellBusinessUnit.setCellValue("Nova unidade de Negocio");

            for (Row row : sheet) {
                System.out.println(row.getCell(0).getStringCellValue());
                if (row.getCell(0).getStringCellValue().equals("INCLUIR")) {
                    for (Cell cell : row) {
                        System.out.println(cell);
                    }
                    row.getCell(8).setCellValue("Processada!");
                }
            }

            File file = new File("C:/temp/modelNew.xls");
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            workbook.write(fileOutputStream);

        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InvalidFormatException e) {
            throw new RuntimeException(e);
        }

    }
}
